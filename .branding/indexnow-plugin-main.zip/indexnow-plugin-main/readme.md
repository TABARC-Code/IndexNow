# IndexNow Auto Submit (WordPress Plugin)

A lightweight WordPress plugin to automatically **submit URLs and your sitemap to IndexNow** whenever you publish or update posts, pages, or events.

### Features
- Auto-pings **IndexNow** (Bing, Yandex, Seznam, Naver, and supported search engines).
- Submits both **individual post URLs** and your **sitemap**.
- Supports `post`, `page`, and `event` (add your own custom post types).
- No admin bloat, just works in the background.

---

## Installation
1. Download or clone this repo.
2. Place the folder `indexnow-plugin` in your WordPress `wp-content/plugins/` directory.
3. Activate the plugin from your WordPress Admin → Plugins page.
4. Generate a **free IndexNow key**:
   - Create a random 32-character string (e.g. `a7b9cdef1234567890abcdef12345678`).
   - Save it into a `.txt` file named with the key itself.
   - Upload it to your site root:  
     `https://yourdomain.com/a7b9cdef1234567890abcdef12345678.txt`
5. Open `indexnow-plugin.php` and replace:
   ```php
   define( 'INDEXNOW_KEY', 'YOUR_KEY_HERE' );
